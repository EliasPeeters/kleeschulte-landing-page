
const startBlockImage = document.getElementById('startBlock')
const startBlockText = document.getElementById('startBlockText')

setInterval(() => {
    startBlockText.classList.toggle('visible')
}, 8000)